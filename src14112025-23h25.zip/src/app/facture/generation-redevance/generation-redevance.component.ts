import { Component } from '@angular/core';
import {GenerationRedevanceCrudComponent} from "./generation-redevance-crud/generation-redevance-crud.component";
import {MatDialog} from "@angular/material/dialog";
import {Router} from "@angular/router";

@Component({
  selector: 'generation-redevance',
  templateUrl: './generation-redevance.component.html',
  styleUrls: ['./generation-redevance.component.scss']
})
export class GenerationRedevanceComponent {

  ngAfterViewInit(): void {

  }

  ngOnDestroy(): void {

  }
}
