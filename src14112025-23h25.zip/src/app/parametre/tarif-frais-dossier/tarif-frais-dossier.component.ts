import { Component } from '@angular/core';

@Component({
  selector: 'app-tarif-frais-dossier',
  templateUrl: './tarif-frais-dossier.component.html',
  styleUrl: './tarif-frais-dossier.component.scss'
})
export class TarifFraisDossierComponent {

}
