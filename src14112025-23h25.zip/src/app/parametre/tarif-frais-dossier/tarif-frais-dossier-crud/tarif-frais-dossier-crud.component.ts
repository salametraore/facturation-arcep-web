import { Component } from '@angular/core';

@Component({
  selector: 'app-tarif-frais-dossier-crud',
  templateUrl: './tarif-frais-dossier-crud.component.html',
  styleUrl: './tarif-frais-dossier-crud.component.scss'
})
export class TarifFraisDossierCrudComponent {

}
