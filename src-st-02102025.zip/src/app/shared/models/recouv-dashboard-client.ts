export class RecouvDashboardClient {
  id: number;
  client_id: number;
  type_client: string;
  client: string;
  compte_comptable: string;
  email: string;
  telephone: string;
  nbre_factures_impayes: number;
  total_du: number;
  avance_du: number;
}
