export class TypeStation {
  id?: number;
  code?: string;
  libelle?: string;
  categorieProduit?: number;
}
