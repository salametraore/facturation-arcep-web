

export class FicheTechniquesProduits {
    id?: number;
    produit?: number;
    produit_libelle?: string;
    designation?: string;
    quantite?: number | null;
    prix_unitaire?: number | null;
}

