export class Dialog {
  title?: string;
  message!: string;
}
