import { Component } from '@angular/core';

@Component({
  selector: 'app-tarif-frequence',
  templateUrl: './tarif-frequence.component.html',
  styleUrl: './tarif-frequence.component.scss'
})
export class TarifFrequenceComponent {

}
