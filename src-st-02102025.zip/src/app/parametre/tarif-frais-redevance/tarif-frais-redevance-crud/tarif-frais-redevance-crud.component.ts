import { Component } from '@angular/core';

@Component({
  selector: 'app-tarif-frais-redevance-crud',
  templateUrl: './tarif-frais-redevance-crud.component.html',
  styleUrl: './tarif-frais-redevance-crud.component.scss'
})
export class TarifFraisRedevanceCrudComponent {

}
