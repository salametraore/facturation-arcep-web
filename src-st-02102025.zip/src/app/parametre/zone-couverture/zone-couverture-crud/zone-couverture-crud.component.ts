import { Component } from '@angular/core';

@Component({
  selector: 'app-zone-couverture-crud',
  templateUrl: './zone-couverture-crud.component.html',
  styleUrl: './zone-couverture-crud.component.scss'
})
export class ZoneCouvertureCrudComponent {

}
