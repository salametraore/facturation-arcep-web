import {AfterViewInit, Component, EventEmitter, Input, OnInit, Output, ViewChild} from '@angular/core';
import {MatPaginator} from "@angular/material/paginator";
import {MatSort} from "@angular/material/sort";
import {FormBuilder, FormGroup} from "@angular/forms";
import {MsgMessageServiceService} from "../../../shared/services/msg-message-service.service";
import {DialogService} from "../../../shared/services/dialog.service";
import {MatTableDataSource} from "@angular/material/table";
import {FicheTechniques} from "../../../shared/models/ficheTechniques";
import {CategorieProduit} from "../../../shared/models/categorie-produit";
import {StatutFicheTechnique} from "../../../shared/models/statut-fiche-technique";
import {Client} from "../../../shared/models/client";
import {FicheTechniquesService} from "../../../shared/services/fiche-techniques.service";
import {CategorieProduitService} from "../../../shared/services/categorie-produit.service";
import {ProduitService} from "../../../shared/services/produits.service";
import {ClientService} from "../../../shared/services/client.service";
import {StatutFicheTechniqueService} from "../../../shared/services/statut-fiche-technique.service";
import {FicheTechniquesProduits} from "../../../shared/models/ficheTechniquesProduits";
import {operations} from "../../../constantes";
import {Produit} from "../../../shared/models/produit";

@Component({
  selector: 'ficher-technique-dfc-crud',
  templateUrl: './ficher-technique-dfc-crud.component.html',
  styleUrl: './ficher-technique-dfc-crud.component.scss'
})
export class FicherTechniqueDfcCrudComponent implements OnInit,AfterViewInit {

  @Input() fixeCategorie:number;
  @Input() ficheTechnique:FicheTechniques;
  @Input() operation:string;
  @Output() notifyFicheTechnique: EventEmitter<FicheTechniques> = new EventEmitter<FicheTechniques>();
  @Output() notifyActionOperation: EventEmitter<string> = new EventEmitter<string>();
  clients:Client[];
  client:Client;
  categories:CategorieProduit[];
  categorie:CategorieProduit;
  statutFicheTechniques:StatutFicheTechnique[];
  statutFicheTechnique:StatutFicheTechnique;
  form_ficheTechnique: FormGroup;
  form_ficheTechniquesProduit: FormGroup;
  t_FicheTechniquesProduits?: MatTableDataSource<FicheTechniquesProduits>;

  displayedColumns: string[] = ['designation', 'prix_unitaire', 'quantite', 'actions'];
  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;
  montant_de_la_commade: number=0;
  produits: Produit[];

  constructor(
    private formBuilder: FormBuilder,
    private ficheTechniquesService: FicheTechniquesService,
    private categorieProduitService: CategorieProduitService,
    private produitService: ProduitService,
    private clientService: ClientService,
    private statutFicheTechniqueService: StatutFicheTechniqueService,
    private msg: MsgMessageServiceService,
    private dialogService: DialogService,
  ) {
    this.t_FicheTechniquesProduits = new MatTableDataSource<FicheTechniquesProduits>([]);
  }

  ngAfterViewInit(): void {
    this.t_FicheTechniquesProduits.paginator = this.paginator;
    this.t_FicheTechniquesProduits.sort = this.sort;
  }

  ngOnInit(): void {
    this.loadData();
    this.initFormCommandeClient_create();
    this.initFormFicheTechniquesProduit_create();
    if (this.ficheTechnique) {
      this.initFormCommandeClient_update();
    }
  }

  loadData() {
    this.categorieProduitService.getListItems().subscribe((categories: CategorieProduit[]) => {
      this.categories = categories;
    });
    this.statutFicheTechniqueService.getListItems().subscribe((statutFicheTechniques: StatutFicheTechnique[]) => {
      this.statutFicheTechniques = statutFicheTechniques.filter(st => st.id < 7);
    });
    this.clientService.getItems().subscribe((clients: Client[]) => {
      this.clients = clients;
    });

    this.clientService.getItems().subscribe((clients: Client[]) => {
      this.clients = clients;
    });

    this.produitService.getListItems().subscribe((produits: Produit[]) => {
      this.produits = produits.filter(f => f.categorieProduit === this.fixeCategorie);
    });
  }

  initFormCommandeClient_create() {
    this.form_ficheTechnique = this.formBuilder.group({
      id: [],
      client: [this.ficheTechnique?.client],
      objet: [],
      periode: [],
      type: [],
      numeroCompte: [],
      signataire: [],
      commentaire: [],
    });
  }

  initFormCommandeClient_update() {
    this.form_ficheTechnique = this.formBuilder.group({
      id: [],
      client: [this.ficheTechnique?.client],
      objet: [],
      periode: [],
      type: [],
      numeroCompte: [],
      signataire: [],
      commentaire: [],
    });
  }

  onGetClient(item: Client) {
    this.client = item;
    this.form_ficheTechnique.get('numeroCompte').setValue(item.compte_comptable);
  }

  initFormFicheTechniquesProduit_create() {
    this.form_ficheTechniquesProduit = this.formBuilder.group({
      id: [''],
      designation: [''],
      prix_unitaire: [''],
      quantite: [''],
    });
  }

  onAdd() {
    const ficheTechniquesProduit:FicheTechniquesProduits = new FicheTechniquesProduits();
    const formValue = this.form_ficheTechniquesProduit.value;
    ficheTechniquesProduit.designation = formValue['designation'];
    ficheTechniquesProduit.quantite = formValue['quantite'];
    ficheTechniquesProduit.prix_unitaire = formValue['prix_unitaire'];
    if (this.t_FicheTechniquesProduits.data?.find(ap => ap.id === ficheTechniquesProduit.id)) {
      this.dialogService.yes_no({
        title: 'Confirmation de modifiaction',
        message: 'Ce produit existe déjà dans la commande, voulez-vous le modifier  ?'
      }).subscribe(yes_no => {
        if (yes_no === true) {
          this.delete_ligneCommande(ficheTechniquesProduit);
          this.add_ligneCommande(ficheTechniquesProduit);
        }
      });
    } else {
      this.add_ligneCommande(ficheTechniquesProduit);
    }
  }

  add_ligneCommande(ficheTechniquesProduit: FicheTechniquesProduits) {
    // Ajouter l'élément à la liste existante
    this.t_FicheTechniquesProduits.data.push(ficheTechniquesProduit);

// Réaffecter le tableau mis à jour à la source de données
    this.t_FicheTechniquesProduits.data = [...this.t_FicheTechniquesProduits.data]; // Création d'une nouvelle référence
    this.initFormFicheTechniquesProduit_create();
    this.getMontantTotal([...this.t_FicheTechniquesProduits.data]);
  }

  onUpdate(ficheTechniquesProduit: FicheTechniquesProduits) {
    this.form_ficheTechniquesProduit = this.formBuilder.group({
      id: [ficheTechniquesProduit?.id],
      designation: [ficheTechniquesProduit?.designation],
      quantite: [ficheTechniquesProduit?.quantite],
      prix_unitaire: [ficheTechniquesProduit?.prix_unitaire],
    });
  }

  onDelete(ficheTechniquesProduit: FicheTechniquesProduits) {
    this.dialogService.yes_no({
      title: 'Confirmation de la suppression',
      message: 'Confirmez-vous supprimer ce produit de la commande ?'
    }).subscribe(yes_no => {
      if (yes_no === true) {
        this.delete_ligneCommande(ficheTechniquesProduit);
      }
    });
  }

  delete_ligneCommande(ficheTechniquesProduit: FicheTechniquesProduits) {
    this.t_FicheTechniquesProduits.data = this.t_FicheTechniquesProduits.data.filter(p => p.id !== ficheTechniquesProduit.id);
    // Rafraîchir la table
    this.t_FicheTechniquesProduits._updateChangeSubscription();
    this.getMontantTotal([...this.t_FicheTechniquesProduits.data]);
  }

  getMontantTotal(ficheTechniquesProduits: FicheTechniquesProduits[]) {
    this.montant_de_la_commade = 0;
    if (ficheTechniquesProduits?.length > 0) {
      this.t_FicheTechniquesProduits.data.forEach((ficheTechniquesProduit: FicheTechniquesProduits) => {
        this.montant_de_la_commade += ficheTechniquesProduit.quantite * ficheTechniquesProduit.prix_unitaire;
      });
    } else {
      return 0;
    }
  }

  onPrint() {

  }

  onSave() {

  }

  onRetour() {
    this.notifyActionOperation.emit(operations.table);
    this.ficheTechnique= undefined;
    this.notifyFicheTechnique.emit(this.ficheTechnique);
  }
}
