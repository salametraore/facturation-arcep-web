export class ModePaiement {
  readonly id: number;
  created_at?: string;
  updated_at?: string;
  libelle: string;
  created_by?: number | null;
  updated_by?: number | null;
}
