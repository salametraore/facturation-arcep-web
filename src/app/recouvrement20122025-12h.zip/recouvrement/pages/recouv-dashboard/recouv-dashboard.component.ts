import { Component } from '@angular/core';

@Component({
  selector: 'recouv-dashboard',
  templateUrl: './recouv-dashboard.component.html',
  styleUrl: './recouv-dashboard.component.scss'
})
export class RecouvDashboardComponent {

}
