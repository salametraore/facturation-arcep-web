import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { finalize } from 'rxjs/operators';

import { RcvPromessesApi, RcvPromesseEnriched, RcvPromesseStatut } from '../../../rcv/endpoints/rcv-promesses.api';

export interface RecouvPromesseDetailsDialogData {
  id: number;
}

@Component({
  selector: 'recouv-promesses-details-dialog',
  templateUrl: './recouv-promesses-details-dialog.component.html',
  styleUrls:  ['./recouv-promesses-details-dialog.component.scss']
})
export class RecouvPromessesDetailsDialogComponent implements OnInit {
  loading = false;
  saving = false;

  promesse!: RcvPromesseEnriched;

  statuts: RcvPromesseStatut[] = ['EN_COURS', 'RESPECTEE', 'NON_RESPECTEE'];

  // champs éditables
  edit = {
    montant: 0,
    date_promesse: '',
    statut: 'EN_COURS' as RcvPromesseStatut
  };

  constructor(
    private api: RcvPromessesApi,
    private ref: MatDialogRef<RecouvPromessesDetailsDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: RecouvPromesseDetailsDialogData
  ) {}

  ngOnInit(): void {
    this.reload();
  }

  reload(): void {
    this.loading = true;
    this.api.getById(this.data.id)
      .pipe(finalize(() => (this.loading = false)))
      .subscribe({
        next: p => {
          this.promesse = p;
          this.edit = {
            montant: p.montant,
            date_promesse: p.date_promesse,
            statut: p.statut
          };
        },
        error: err => {
          console.error(err);
          this.ref.close(false);
        }
      });
  }

  clientLabel(): string {
    return this.promesse?.client?.denomination
      ?? this.promesse?.client?.denomination_sociale
        ?? `Client #${this.promesse?.client_id}`;
  }

  factureLabel(): string {
    if (!this.promesse?.facture_id) return 'Promesse globale';
    return this.promesse?.facture?.reference ?? `Facture #${this.promesse?.facture_id}`;
  }

  save(): void {
    if (!this.promesse) return;

    this.saving = true;
    this.api.update(this.promesse.id, {
      montant: this.edit.montant,
      date_promesse: this.edit.date_promesse,
      statut: this.edit.statut
    })
      .pipe(finalize(() => (this.saving = false)))
      .subscribe({
        next: () => this.ref.close(true),
        error: err => console.error(err)
      });
  }

  close(): void {
    this.ref.close(false);
  }
}
