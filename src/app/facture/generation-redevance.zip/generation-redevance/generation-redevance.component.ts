import { Component } from '@angular/core';

@Component({
  selector: 'generation-redevance',
  templateUrl: './generation-redevance.component.html',
  styleUrls: ['./generation-redevance.component.scss']
})
export class GenerationRedevanceComponent {}
