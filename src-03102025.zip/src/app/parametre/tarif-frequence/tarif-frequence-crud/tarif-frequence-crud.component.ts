import { Component } from '@angular/core';

@Component({
  selector: 'app-tarif-frequence-crud',
  templateUrl: './tarif-frequence-crud.component.html',
  styleUrl: './tarif-frequence-crud.component.scss'
})
export class TarifFrequenceCrudComponent {

}
