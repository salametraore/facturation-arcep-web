import { Component } from '@angular/core';

@Component({
  selector: 'app-categorie-station-crud',
  templateUrl: './categorie-station-crud.component.html',
  styleUrl: './categorie-station-crud.component.scss'
})
export class CategorieStationCrudComponent {

}
