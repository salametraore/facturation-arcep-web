import { Component } from '@angular/core';

@Component({
  selector: 'app-zone-postale-crud',
  templateUrl: './zone-postale-crud.component.html',
  styleUrl: './zone-postale-crud.component.scss'
})
export class ZonePostaleCrudComponent {

}
