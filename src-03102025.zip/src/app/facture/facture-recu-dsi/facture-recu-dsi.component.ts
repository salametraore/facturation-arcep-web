import { Component } from '@angular/core';

@Component({
  selector: 'app-facture-recu-dsi',
  templateUrl: './facture-recu-dsi.component.html',
  styleUrl: './facture-recu-dsi.component.scss'
})
export class FactureRecuDsiComponent {

}
