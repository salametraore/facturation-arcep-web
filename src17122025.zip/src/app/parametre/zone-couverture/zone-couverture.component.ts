import { Component } from '@angular/core';

@Component({
  selector: 'app-zone-couverture',
  templateUrl: './zone-couverture.component.html',
  styleUrl: './zone-couverture.component.scss'
})
export class ZoneCouvertureComponent {

}
