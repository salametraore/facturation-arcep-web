export class ElementFacturationRecuCreeList {
   id?: number;
  id_client?: number;
  client?: string;
  compte_comptable?: string;
  element_facturation_recu_id?: number;
  categorie_produit_id?: number;
  type_frais?: string;
  fiche_technique_id?: number;
  date_soumission: Date;
}
