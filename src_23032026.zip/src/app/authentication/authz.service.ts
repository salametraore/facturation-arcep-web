// src/app/authentication/authz.service.ts

import { Injectable, computed, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, tap, catchError } from 'rxjs';

import { AppConfigService } from '../core/config/app-config.service';
import { AccessPayload, ScopedResource, AccessRoleScope } from './access.models';
import { MenuItem } from '../core/menu/menu-items';

@Injectable({ providedIn: 'root' })
export class AuthzService {
  private readonly ACCESS_KEY = 'rbac_access';

  private get apiUrl(): string {
    return this.cfg.baseUrl.replace(/\/$/, '');
  }

  private readonly _access = signal<AccessPayload | null>(this.readFromSession());

  readonly access = computed(() => this._access());
  readonly accessLoaded = computed(() => this._access() !== null);
  readonly user = computed(() => this._access()?.user ?? null);
  readonly roles = computed(() => this._access()?.roles ?? []);
  readonly permissions = computed(() => this._access()?.permissions ?? []);
  readonly permissionsSet = computed(() => new Set(this.permissions()));

  constructor(
    private http: HttpClient,
    private cfg: AppConfigService
  ) {}

  private readFromSession(): AccessPayload | null {
    const raw = sessionStorage.getItem(this.ACCESS_KEY);
    if (!raw) {
      return null;
    }

    try {
      return JSON.parse(raw) as AccessPayload;
    } catch {
      sessionStorage.removeItem(this.ACCESS_KEY);
      return null;
    }
  }

  setAccess(payload: AccessPayload | null): void {
    this._access.set(payload);

    if (payload) {
      sessionStorage.setItem(this.ACCESS_KEY, JSON.stringify(payload));
    } else {
      sessionStorage.removeItem(this.ACCESS_KEY);
    }
  }

  clear(): void {
    this.setAccess(null);
  }

  refreshAccess(): Observable<AccessPayload> {
    return this.http
      .get<AccessPayload>(`${this.apiUrl}/auth/me/access/`)
      .pipe(tap(payload => this.setAccess(payload)));
  }

  ensureAccessLoaded(): Observable<AccessPayload | null> {
    const current = this._access();
    if (current) {
      return of(current);
    }

    return this.refreshAccess().pipe(
      catchError(() => {
        this.clear();
        return of(null);
      })
    );
  }

  has(permission: string): boolean {
    return this.permissionsSet().has(permission);
  }

  hasAny(permissions: string[] | null | undefined): boolean {
    if (!permissions?.length) {
      return true;
    }

    const set = this.permissionsSet();
    return permissions.some(permission => set.has(permission));
  }

  hasAll(permissions: string[] | null | undefined): boolean {
    if (!permissions?.length) {
      return true;
    }

    const set = this.permissionsSet();
    return permissions.every(permission => set.has(permission));
  }

  canRoute(requiredAny?: string[] | null, requiredAll?: string[] | null): boolean {
    return this.hasAny(requiredAny) && this.hasAll(requiredAll);
  }

  canOnResource(
    permission: string,
    resource?: ScopedResource | null
  ): boolean {
    if (!this.has(permission)) {
      return false;
    }

    if (!resource) {
      return true;
    }

    const roles = this.roles();
    if (!roles.length) {
      return false;
    }

    return roles.some(role => this.roleMatchesResource(role, resource));
  }

  canAnyOnResource(
    permissions: string[] | null | undefined,
    resource?: ScopedResource | null
  ): boolean {
    if (!permissions?.length) {
      return true;
    }

    return permissions.some(permission => this.canOnResource(permission, resource));
  }

  canAllOnResource(
    permissions: string[] | null | undefined,
    resource?: ScopedResource | null
  ): boolean {
    if (!permissions?.length) {
      return true;
    }

    return permissions.every(permission => this.canOnResource(permission, resource));
  }

  private roleMatchesResource(role: AccessRoleScope, resource: ScopedResource): boolean {
    if (role.is_global) {
      return true;
    }

    const directionOk =
      role.direction_id == null ||
      resource.direction_id == null ||
      Number(role.direction_id) === Number(resource.direction_id);

    const produitOk =
      role.produit_id == null ||
      resource.produit_id == null ||
      Number(role.produit_id) === Number(resource.produit_id);

    return directionOk && produitOk;
  }

  filterMenu(items: MenuItem[]): MenuItem[] {
    return items
      .filter(item => this.isMenuItemVisible(item))
      .map(item => ({
        ...item,
        sous_menus: item.sous_menus ? this.filterMenu(item.sous_menus) : null
      }))
      .filter(item => item.feuille === 1 || (item.sous_menus?.length ?? 0) > 0);
  }

  private isMenuItemVisible(item: MenuItem): boolean {
    if (item.actif !== 'OUI') {
      return false;
    }

    return this.canRoute(item.requiredAny, item.requiredAll);
  }
}
