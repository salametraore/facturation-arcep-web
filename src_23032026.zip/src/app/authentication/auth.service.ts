/// backoffice -  src/app/authentication/auth.service.ts

import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { BehaviorSubject, forkJoin, Observable, of, throwError } from 'rxjs';
import { catchError, map, switchMap, tap } from 'rxjs/operators';

import {
  LoginPayload,
  LoginResponse,
  TwoFaPayload,
  AuthState,
  User,
  PasswordResetPayload,
  PasswordResetConfirmPayload,
  VerifyResetCodePayload
} from './auth.models';

import { Utilisateur } from '../shared/models/utilisateur';
import { UtilisateurRole } from '../shared/models/droits-utilisateur';

import { AppConfigService } from '../core/config/app-config.service';
import { UtilisateurService } from '../shared/services/utilisateur.service';
import { UtilisateurRoleService } from '../shared/services/utilsateur-role.service';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly TOKEN_KEY = 'auth_token';
  private readonly USER_KEY = 'user';
  private readonly CONNECTED_USER_KEY = 'UtilisateurConnecte';
  private readonly CONNECTED_ROLE_KEY = 'utilisateurRole';
  private readonly AUTH_ERROR_KEY = 'auth_error';

  private get apiUrl(): string {
    return this.cfg.baseUrl.replace(/\/$/, '');
  }

  private authState = new BehaviorSubject<AuthState>(this.getInitialState());
  public authState$ = this.authState.asObservable();

  private authErrorSubject = new BehaviorSubject<string | null>(
    sessionStorage.getItem(this.AUTH_ERROR_KEY)
  );
  public authError$ = this.authErrorSubject.asObservable();

  utilisateurConnecte!: Utilisateur;

  constructor(
    private http: HttpClient,
    private router: Router,
    private cfg: AppConfigService,
    private utilisateurService: UtilisateurService,
    private utilisateurRoleService: UtilisateurRoleService
  ) {}

  private getInitialState(): AuthState {
    const token = sessionStorage.getItem(this.TOKEN_KEY);
    const userStr = sessionStorage.getItem(this.USER_KEY);
    const user = userStr ? (JSON.parse(userStr) as User) : null;
    return { isAuthenticated: !!token, token, user };
  }

  private setAuthError(msg: string | null): void {
    this.authErrorSubject.next(msg);
    if (msg) {
      sessionStorage.setItem(this.AUTH_ERROR_KEY, msg);
    } else {
      sessionStorage.removeItem(this.AUTH_ERROR_KEY);
    }
  }

  clearAuthError(): void {
    this.setAuthError(null);
  }

  private clearSessionStorage(preserveAuthError = false): void {
    sessionStorage.removeItem(this.TOKEN_KEY);
    sessionStorage.removeItem(this.USER_KEY);
    sessionStorage.removeItem(this.CONNECTED_USER_KEY);
    sessionStorage.removeItem(this.CONNECTED_ROLE_KEY);

    if (!preserveAuthError) {
      sessionStorage.removeItem(this.AUTH_ERROR_KEY);
      this.authErrorSubject.next(null);
    }

    this.authState.next({
      isAuthenticated: false,
      token: null,
      user: null
    });
  }

  private isPersonnel(util: any): boolean {
    const home = String(util?.home ?? '').toUpperCase();
    if (home) {
      return home === 'BACKOFFICE';
    }

    return String(util?.nature ?? '').toUpperCase() === 'PERSONNEL';
  }

  login(payload: LoginPayload): Observable<LoginResponse> {
    this.setAuthError(null);
    const url = `${this.apiUrl}/auth/login/`;
    return this.http.post<LoginResponse>(url, payload).pipe(
      catchError(this.handleError)
    );
  }

  verify2fa(payload: TwoFaPayload): Observable<LoginResponse> {
    const url = `${this.apiUrl}/auth/verify-otp/`;
    return this.http.post<LoginResponse>(url, payload).pipe(
      catchError(this.handleError)
    );
  }

  /**
   * Centralise toute l'hydratation de session :
   * - pose token + user
   * - charge le profil interne complet
   * - charge le rôle associé si disponible
   */
  completeAuthenticatedSession(response: LoginResponse): Observable<void> {
    if (!response?.token || !response?.user) {
      return throwError(() => new Error('Réponse d’authentification invalide.'));
    }

    if (!this.isPersonnel(response.user)) {
      this.setAuthError(
        "Cette application est réservée aux utilisateurs internes. Veuillez utiliser l'application Portail Client."
      );
      this.clearSessionStorage(true);
      this.router.navigate(['/auth/login']);
      return throwError(() => new Error('Accès réservé au backoffice.'));
    }

    this.setToken(response.token, response.user);

    const userId = Number((response.user as any)?.id);

    if (!userId) {
      this.setAuthError('Identifiant utilisateur invalide dans la réponse d’authentification.');
      this.clearSessionStorage(true);
      this.router.navigate(['/auth/login']);
      return throwError(() => new Error('Identifiant utilisateur invalide.'));
    }

    const user$ = this.utilisateurService.getItem(userId);

    const role$ = this.utilisateurRoleService.getListItems().pipe(
      map((items: UtilisateurRole[]) => this.findRoleForUser(items, response.user)),
      catchError(() => of(null))
    );

    return forkJoin({ user: user$, role: role$ }).pipe(
      tap(({ user, role }) => {
        this.utilisateurConnecte = user;

        if (!this.isPersonnel(user)) {
          throw new Error('Compte non autorisé pour le backoffice.');
        }

        this.setConnectedUser(user);
        this.setConnectedUtilisateurRole(role);
        this.setAuthError(null);
      }),
      map(() => void 0),
      catchError((err) => {
        this.setAuthError(err?.message || 'Impossible de charger le profil utilisateur.');
        this.clearSessionStorage(true);
        this.router.navigate(['/auth/login']);
        return throwError(() =>
          err instanceof Error ? err : new Error('Impossible de charger le profil utilisateur.')
        );
      })
    );
  }

  private findRoleForUser(items: UtilisateurRole[] | null | undefined, authUser: User): UtilisateurRole | null {
    const userId = Number((authUser as any)?.id ?? 0);
    const username = String((authUser as any)?.username ?? '').toLowerCase();
    const email = String((authUser as any)?.email ?? '').toLowerCase();

    const found = (items ?? []).find((it: any) => {
      const candidateId = Number(
        it?.utilisateur_id ??
          it?.utilisateur?.id ??
            it?.user_id ??
              it?.user?.id ??
                0
      );

      const candidateUsername = String(
        it?.utilisateur_username ??
          it?.utilisateur?.username ??
            it?.user?.username ??
              it?.username ??
                ''
      ).toLowerCase();

      const candidateEmail = String(
        it?.utilisateur_email ??
          it?.utilisateur?.email ??
            it?.user?.email ??
              it?.email ??
                it?.utilisateur ??
                  ''
      ).toLowerCase();

      return (
        (userId > 0 && candidateId === userId) ||
        (!!username && candidateUsername === username) ||
        (!!email && candidateEmail === email)
      );
    });

    return found ?? null;
  }

  private setToken(token: string, user: User): void {
    sessionStorage.setItem(this.TOKEN_KEY, token);
    sessionStorage.setItem(this.USER_KEY, JSON.stringify(user));
    this.authState.next({ isAuthenticated: true, token, user });
  }

  public getToken(): string | null {
    return sessionStorage.getItem(this.TOKEN_KEY);
  }

  public hasToken(): boolean {
    return !!this.getToken();
  }

  setConnectedUser(utilisateur: Utilisateur): void {
    sessionStorage.setItem(this.CONNECTED_USER_KEY, JSON.stringify(utilisateur));
  }

  getConnectedUser(): Utilisateur | null {
    const s = sessionStorage.getItem(this.CONNECTED_USER_KEY);
    return s ? (JSON.parse(s) as Utilisateur) : null;
  }

  setConnectedUtilisateurRole(utilisateurRole: UtilisateurRole | null): void {
    if (utilisateurRole) {
      sessionStorage.setItem(this.CONNECTED_ROLE_KEY, JSON.stringify(utilisateurRole));
    } else {
      sessionStorage.removeItem(this.CONNECTED_ROLE_KEY);
    }
  }

  getConnectedUtilisateurRole(): UtilisateurRole | null {
    const s = sessionStorage.getItem(this.CONNECTED_ROLE_KEY);
    return s ? (JSON.parse(s) as UtilisateurRole) : null;
  }

  logout(): void {
    this.clearSessionStorage(false);
    this.router.navigate(['/auth/login']);
  }

  public isAuthenticated(): boolean {
    return this.hasToken();
  }

  requestPasswordReset(payload: PasswordResetPayload): Observable<any> {
    const url = `${this.apiUrl}/password_reset/`;
    return this.http.post(url, payload).pipe(catchError(this.handleError));
  }

  verifyResetCode(payload: VerifyResetCodePayload): Observable<any> {
    const url = `${this.apiUrl}/password_reset/verify-reset-code/`;
    return this.http.post(url, payload).pipe(catchError(this.handleError));
  }

  confirmPasswordReset(payload: PasswordResetConfirmPayload): Observable<any> {
    const url = `${this.apiUrl}/password_reset/confirm/`;
    return this.http.post(url, payload).pipe(catchError(this.handleError));
  }

  private handleError(error: HttpErrorResponse) {
    let errorMessage = 'Une erreur est survenue.';

    if (error.status === 0) {
      errorMessage = 'Impossible de joindre le serveur.';
      return throwError(() => new Error(errorMessage));
    }

    if (error.status === 401 || error.status === 403) {
      errorMessage = 'Identifiants, code OTP ou droits d’accès invalides.';
      return throwError(() => new Error(errorMessage));
    }

    if (typeof error.error?.message === 'string' && error.error.message.trim()) {
      errorMessage = error.error.message;
    } else if (typeof error.error?.detail === 'string' && error.error.detail.trim()) {
      errorMessage = error.error.detail;
    }

    return throwError(() => new Error(errorMessage));
  }
}
