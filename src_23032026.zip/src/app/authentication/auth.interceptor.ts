///src/app/authentication/auth.interceptor.ts
import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { AuthService } from './auth.service';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  private readonly excludedUrls: string[] = [
    '/auth/login/',
    '/auth/verify-otp/',
    '/password_reset/',
    '/password_reset/verify-reset-code/',
    '/password_reset/confirm/'
  ];

  constructor(private authService: AuthService) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    const shouldExclude = this.excludedUrls.some(url => request.url.includes(url));

    if (shouldExclude) {
      return next.handle(request);
    }

    const token = this.authService.getToken();

    if (!token) {
      return next.handle(request);
    }

    const cloned = request.clone({
      setHeaders: {
        Authorization: `Token ${token}`
      }
    });

    return next.handle(cloned);
  }
}
