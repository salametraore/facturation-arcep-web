export interface AccessUser {
  id: number;
  username: string;
  email?: string | null;
  first_name?: string | null;
  last_name?: string | null;
}

export interface AccessRoleScope {
  code: string;
  direction_id?: number | null;
  produit_id?: number | null;
  is_global?: boolean;
}

export interface AccessPayload {
  user: AccessUser;
  roles: AccessRoleScope[];
  permissions: string[];
}

export interface ScopedResource {
  direction_id?: number | null;
  produit_id?: number | null;
  [key: string]: any;
}

export interface AllowedActionsMap {
  [action: string]: boolean;
}
