///src/app/core/menu/menu-security.service.ts

import { Injectable } from '@angular/core';
import { MenuItem } from './menu-items';
import { AuthService } from '../../authentication/auth.service';
import { UtilisateurRole } from '../../shared/models/droits-utilisateur';

@Injectable({ providedIn: 'root' })
export class MenuSecurityService {
  constructor(private authService: AuthService) {}

  filter(items: MenuItem[]): MenuItem[] {
    return items
      .filter(item => this.isVisible(item))
      .map(item => ({
        ...item,
        sous_menus: item.sous_menus ? this.filter(item.sous_menus) : null
      }))
      .filter(item => item.feuille === 1 || (item.sous_menus?.length ?? 0) > 0);
  }

  private isVisible(item: MenuItem): boolean {
    if (item.actif !== 'OUI') {
      return false;
    }

    const permissions = new Set(this.extractPermissions(this.authService.getConnectedUtilisateurRole()));

    const okAny =
      !item.requiredAny?.length ||
      item.requiredAny.some(permission => permissions.has(permission));

    const okAll =
      !item.requiredAll?.length ||
      item.requiredAll.every(permission => permissions.has(permission));

    return okAny && okAll;
  }

  private extractPermissions(role: UtilisateurRole | null): string[] {
    const raw =
      (role as any)?.permissions ??
        (role as any)?.role?.permissions ??
          [];

    if (!Array.isArray(raw)) {
      return [];
    }

    return raw
      .map((p: any) => {
        if (typeof p === 'string') {
          return p;
        }
        return String(p?.code ?? p?.name ?? '').trim();
      })
      .filter((p: string) => !!p);
  }
}
