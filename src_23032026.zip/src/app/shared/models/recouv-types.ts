export type RcvTypeClient = string;
