import { Component } from '@angular/core';

@Component({
  selector: 'app-garantie-crud',
  templateUrl: './garantie-crud.component.html',
  styleUrl: './garantie-crud.component.scss'
})
export class GarantieCrudComponent {

}
