import { Component } from '@angular/core';

@Component({
  selector: 'app-categorie-station',
  templateUrl: './categorie-station.component.html',
  styleUrl: './categorie-station.component.scss'
})
export class CategorieStationComponent {

}
