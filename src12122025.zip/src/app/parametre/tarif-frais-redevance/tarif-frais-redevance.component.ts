import { Component } from '@angular/core';

@Component({
  selector: 'app-tarif-frais-redevance',
  templateUrl: './tarif-frais-redevance.component.html',
  styleUrl: './tarif-frais-redevance.component.scss'
})
export class TarifFraisRedevanceComponent {

}
