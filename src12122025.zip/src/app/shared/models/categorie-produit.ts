export class CategorieProduit {
  id?: number;  // optionnel si pas encore créé
  code?: string;
  libelle?: string;
  description?: string;
}
