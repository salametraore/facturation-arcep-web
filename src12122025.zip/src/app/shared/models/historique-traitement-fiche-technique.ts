export class  HistoriqueFicheTechnique {
  ordre_chrono: number;
  fiche_technique_id: number;
  tache: string;
  date_tache: string;
}
