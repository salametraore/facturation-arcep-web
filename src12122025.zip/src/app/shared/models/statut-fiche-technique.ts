export class StatutFicheTechnique {
  id?: number;            // facultatif car souvent généré par la base
  code?: string;
  libelle?: string;
}
