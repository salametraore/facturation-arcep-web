export interface LignesFactures {
    id?: number;
    produit?: number;
    quantite?: number;
}
