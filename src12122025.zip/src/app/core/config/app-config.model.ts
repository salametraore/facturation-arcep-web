export interface AppConfig {
  baseUrl: string;
}
