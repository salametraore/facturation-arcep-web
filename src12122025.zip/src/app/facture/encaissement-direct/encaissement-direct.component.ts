import { Component } from '@angular/core';

@Component({
  selector: 'app-encaissement-direct',
  templateUrl: './encaissement-direct.component.html'
})
export class EncaissementDirectComponent {}
