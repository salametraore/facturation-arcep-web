import { Component } from '@angular/core';

@Component({
  selector: 'app-fiche-techniques-activites-postales',
  templateUrl: './fiche-techniques-activites-postales.component.html',
  styleUrl: './fiche-techniques-activites-postales.component.scss'
})
export class FicheTechniquesActivitesPostalesComponent {

}
