export const environment = {
  production: false,
  //baseUrl: 'http://196.43.247.6/backend/facturation_api',
  //baseUrl: 'http://localhost:8000/facturation_api',
};
