// src/polyfills.js
window.global = window;
