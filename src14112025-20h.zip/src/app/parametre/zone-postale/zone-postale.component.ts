import { Component } from '@angular/core';

@Component({
  selector: 'app-zone-postale',
  templateUrl: './zone-postale.component.html',
  styleUrl: './zone-postale.component.scss'
})
export class ZonePostaleComponent {

}
