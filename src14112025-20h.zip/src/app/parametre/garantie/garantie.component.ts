import { Component } from '@angular/core';

@Component({
  selector: 'app-garantie',
  templateUrl: './garantie.component.html',
  styleUrl: './garantie.component.scss'
})
export class GarantieComponent {

}
