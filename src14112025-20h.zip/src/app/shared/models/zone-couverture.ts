export class ZoneCouverture {
  readonly id?: number;
  code?: string;
  libelle?: string;
  categorie_produit?: number;
}
