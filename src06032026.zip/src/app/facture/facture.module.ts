import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FactureRoutingModule } from './facture-routing.module';

import {SharedModule} from "../shared/shared.module";
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {PdfViewerModule} from "ng2-pdf-viewer";
import {FactureDfcComponent} from "./facture-dfc/facture-dfc.component";
import {FactureDetailDfcEnergieComponent} from "./facture-detail-dfc-energie/facture-detail-dfc-energie.component";
import {
  FactureDetailDfcElectriciteComponent
} from "./facture-detail-dfc-electricite/facture-detail-dfc-electricite.component";
import {
  FactureSanctionFinanciereDetailDapComponent
} from "./facture-sanction-financiere-detail-dap/facture-sanction-financiere-detail-dap.component";
import {FicheTechniqueDgsnComponent} from "./fiche-technique-dgsn/fiche-technique-dgsn.component";
import {FactureRecuDgsnComponent} from "./facture-recu-dgsn/facture-recu-dgsn.component";
import {FactureRecuDsiComponent} from "./facture-recu-dsi/facture-recu-dsi.component";
import {FactureRecuDfcComponent} from "./facture-recu-dfc/facture-recu-dfc.component";
import {FactureRecuDfcCrudComponent} from "./facture-recu-dfc/facture-recu-dfc-crud/facture-recu-dfc-crud.component";
import {EncaissementComponent} from "./encaissement/encaissement.component";
import {EncaissementCrudComponent} from "./encaissement/encaissement-crud/encaissement-crud.component";
import {DevisFactureComponent} from "./devis-facture/devis-facture.component";
import {DevisFactureCrudComponent} from "./devis-facture/devis-facture-crud/devis-facture-crud.component";
import {ElementsFactureRecuComponent} from "./elements-facture-recu/elements-facture-recu.component";
import {
  ElementsFactureRecuCrudComponent
} from "./elements-facture-recu/elements-facture-recu-crud/elements-facture-recu-crud.component";
import {FicherTechniqueDfcComponent} from "./gestion-prestations-diverses/ficher-technique-dfc.component";
import {
  FicherTechniqueDfcCrudComponent
} from "./gestion-prestations-diverses/ficher-technique-dfc-crud/ficher-technique-dfc-crud.component";
import {
  FicheTechniqueDfcTableComponent
} from "./gestion-prestations-diverses/fiche-technique-dfc-table/fiche-technique-dfc-table.component";
import {ServiceAValeurAjouteComponent} from "./service-a-valeur-ajoute/service-a-valeur-ajoute.component";
import {
  ServiceAValeurAjouteTableComponent
} from "./service-a-valeur-ajoute/service-a-valeur-ajoute-table/service-a-valeur-ajoute-table.component";
import {
  ServiceAValeurAjouteCrudComponent
} from "./service-a-valeur-ajoute/service-a-valeur-ajoute-crud/service-a-valeur-ajoute-crud.component";
import {AutorisationGeneraleComponent} from "./autorisation-generale/autorisation-generale.component";
import {
  AutorisationGeneraleTableComponent
} from "./autorisation-generale/autorisation-generale-table/autorisation-generale-table.component";
import {
  AutorisationGeneraleCrudComponent
} from "./autorisation-generale/autorisation-generale-crud/autorisation-generale-crud.component";
import { AgrementInstalleurComponent } from './agrement-installeur/agrement-installeur.component';
import { AgrementInstalleurCrudComponent } from './agrement-installeur/agrement-installeur-crud/agrement-installeur-crud.component';
import { AgrementInstalleurTableComponent } from './agrement-installeur/agrement-installeur-table/agrement-installeur-table.component';
import { NumerotationComponent } from './numerotation/numerotation.component';
import { NumerotationTableComponent } from './numerotation/numerotation-table/numerotation-table.component';
import { NumerotationCrudComponent } from './numerotation/numerotation-crud/numerotation-crud.component';
import { AgrementEquipementComponent } from './agrement-equipement/agrement-equipement.component';
import { AgrementEquipementTableComponent } from './agrement-equipement/agrement-equipement-table/agrement-equipement-table.component';
import { AgrementEquipementCrudComponent } from './agrement-equipement/agrement-equipement-crud/agrement-equipement-crud.component';
import {DomaineComponent} from "./domaine/domaine.component";
import {DomaineCrudComponent} from "./domaine/domaine-crud/domaine-crud.component";
import {ServiceConfianceComponent} from "./service-confiance/service-confiance.component";
import {
  ServiceConfianceCrudComponent
} from "./service-confiance/service-confiance-crud/service-confiance-crud.component";
import {AvisEtuteTechniqueDialogComponent} from "./avis-etute-technique-dialog/avis-etute-technique-dialog.component";
import {HistoriqueTraitementComponent} from "./historique-traitement/historique-traitement.component";
import {AvisTechniqueInfosComponent} from "./avis-technique-infos/avis-technique-infos.component";
import { EncaissementDirectComponent } from './encaissement-direct/encaissement-direct.component';
import { EncaissementDirectCrudComponent } from './encaissement-direct/encaissement-direct-crud/encaissement-direct-crud.component';
import {GenerationRedevanceComponent} from "./generation-redevance/generation-redevance.component";
import {GenerationRedevanceCrudComponent} from "./generation-redevance/generation-redevance-crud/generation-redevance-crud.component";
import {RetraitAutorisationDialogComponent} from "./retrait-autorisation-dialog/retrait-autorisation-dialog.component";
import {FrequencesComponent} from "./frequences/frequences.component";
import {FrequencesTableComponent} from "./frequences/frequences-table/frequences-table.component";
import {FrequencesCrudComponent} from "./frequences/frequences-crud/frequences-crud.component";
import { ScrollingModule } from '@angular/cdk/scrolling'
import {ClientDirectionTechniqueComponent} from "./client-direction-technique/client-direction-technique.component";
import {ClientDetailsComponent} from "./client-direction-technique/client-details/client-details.component";
import {ClientDetailsReleveCompteComponent} from "./client-direction-technique/client-details/client-details-releve-compte/client-details-releve-compte.component";
import {ClientDetailsEncaissementsComponent} from "./client-direction-technique/client-details/client-details-encaissements/client-details-encaissements.component";
import {ClientDetailsFacturesComponent} from "./client-direction-technique/client-details/client-details-factures/client-details-factures.component";
import {ClientDetailsFichesTechniques} from "./client-direction-technique/client-details/client-details-fiches-techniques/client-details-fiches-techniques";
import {FactureComponent} from "./facture/facture.component";
import {GestionDevisComponent} from "./gestion-devis/gestion-devis.component";
import {GestionDevisCrudComponent} from "./gestion-devis/gestion-devis-crud/gestion-devis-crud.component";
import {ClientDetailsDevisComponent} from "./client-direction-technique/client-details/client-details-devis/client-details-devis.component";
import {ClientCrudDomaineComponent} from "./client-direction-technique/client-details/client-crud-domaine/client-crud-domaine.component";
import {ClientCrudServiceConfianceComponent} from "./client-direction-technique/client-details/client-crud-service-confiance/client-crud-service-confiance.component";
import {ClientCrudPrestationsDiversesComponent} from "./client-direction-technique/client-details/client-crud-prestations-diverses/client-crud-prestations-diverses.component";
import {ClientCrudServiceAValeurAjouteComponent} from "./client-direction-technique/client-details/client-crud-service-a-valeur-ajoute/client-crud-service-a-valeur-ajoute.component";
import {ClientCrudAutorisationGeneraleComponent} from "./client-direction-technique/client-details/client-crud-autorisation-generale/client-crud-autorisation-generale.component";
import {ClientCrudAgrementInstalleurComponent} from "./client-direction-technique/client-details/client-crud-agrement-installeur/client-crud-agrement-installeur.component";
import {ClientCrudAgrementEquipementComponent} from "./client-direction-technique/client-details/client-crud-agrement-equipement/client-crud-agrement-equipement.component";
import {ClientCrudNumerotationComponent} from "./client-direction-technique/client-details/client-crud-numerotation/client-crud-numerotation.component";
import {StationFrequencesDialogComponent} from "./frequences/modals/station-frequences-dialog/station-frequences-dialog.component";
import {CanalFrequencesDialogComponent} from "./frequences/modals/canal-frequences-dialog/canal-frequences-dialog.component";
import {ClientDetailsImapyesComponent} from "./client-direction-technique/client-details/client-details-impayes/client-details-impayes.component";
import { ImportDocumentsComponent } from './gestion-activites-postales/import-documents/import-documents.component';
import { ImportComptesComponent } from './gestion-activites-postales/import-comptes/import-comptes.component';
import { TraitementBilanComponent } from './gestion-activites-postales/traitement-bilan/traitement-bilan.component';
import { RecapRedevancesComponent } from './gestion-activites-postales/recap-redevances/recap-redevances.component';
import {AutorisationsPostalesComponent} from "./autorisations-postales/autorisations-postales.component";
import {AutorisationsPostalesTableComponent} from "./autorisations-postales/autorisations-postales-table/autorisations-postales-table.component";
import {AutorisationsPostalesCrudComponent} from "./autorisations-postales/autorisations-postales-crud/autorisations-postales-crud.component";
import {ImportDocumentDialogComponent} from "./gestion-activites-postales/import-document-dialog/import-document-dialog.component";
import {ClientDfcComponent} from "./client-dfc/client-dfc.component";
import {ClientDfcDetailsComponent} from "./client-dfc/client-dfc-details/client-dfc-details.component";
import {ClientDfcDetailsReleveCompteComponent} from "./client-dfc/client-dfc-details/client-dfc-details-releve-compte/client-dfc-details-releve-compte.component";
import {ClientDfcDetailsImapyesComponent} from "./client-dfc/client-dfc-details/client-dfc-details-impayes/client-dfc-details-impayes.component";
import {ClientDfcDetailsFacturesComponent} from "./client-dfc/client-dfc-details/client-dfc-details-factures/client-dfc-details-factures.component";
import {ClientDfcDetailsEncaissementsComponent} from "./client-dfc/client-dfc-details/client-dfc-details-encaissements/client-dfc-details-encaissements.component";
import {ClientDfcDetailsDevisComponent} from "./client-dfc/client-dfc-details/client-dfc-details-devis/client-dfc-details-devis.component";
import {ClientDfcEncaissementCrudComponent} from "./client-dfc/client-dfc-details/client-dfc-encaissement-crud/client-dfc-encaissement-crud.component";
import {MaterialModule} from "../material/material.module";
import {FichesTechniquesDapTableComponent} from "./fiche-techniques-activites-postales/fiches-techniques-dap-table/fiches-techniques-dap-table.component";
import {CaPostalDeterminationShellComponent} from "./fiche-techniques-activites-postales/ca-postal-determination-shell/ca-postal-determination-shell.component";
import {FicheTechniquesActivitesPostalesComponent} from "./fiche-techniques-activites-postales/fiche-techniques-activites-postales.component";
import { ImportBilanDialogComponent } from './fiche-techniques-activites-postales/import-bilan-dialog/import-bilan-dialog.component';
import {ClientDfcPenalitesCrudComponent} from "./client-dfc/client-dfc-details/client-dfc-penalites-crud/client-dfc-penalites-crud.component";
import {FichesTechniquesDapCrudComponent} from "./fiche-techniques-activites-postales/fiches-techniques-dap-crud/fiches-techniques-dap-crud.component";


@NgModule({
  declarations: [
    DomaineComponent,
    DomaineCrudComponent,
    ServiceConfianceComponent,
    ServiceConfianceCrudComponent,
    FactureDfcComponent,
    FactureComponent,
    FactureDetailDfcEnergieComponent,
    FactureDetailDfcElectriciteComponent,
    FactureSanctionFinanciereDetailDapComponent,
    FicheTechniqueDgsnComponent,
    FactureRecuDgsnComponent,
    FactureRecuDsiComponent,
    FactureRecuDfcComponent,
    FactureRecuDfcCrudComponent,
    EncaissementComponent,
    EncaissementCrudComponent,
    DevisFactureComponent,
    GestionDevisComponent,
    GestionDevisCrudComponent,
    DevisFactureCrudComponent,
    ElementsFactureRecuComponent,
    ElementsFactureRecuCrudComponent,
    FicherTechniqueDfcComponent,
    FicherTechniqueDfcCrudComponent,
    FicheTechniqueDfcTableComponent,
    ServiceAValeurAjouteComponent,
    ServiceAValeurAjouteTableComponent,
    ServiceAValeurAjouteCrudComponent,
    AutorisationGeneraleComponent,
    AutorisationGeneraleTableComponent,
    AutorisationGeneraleCrudComponent,
    AgrementInstalleurComponent,
    AgrementInstalleurCrudComponent,
    AgrementInstalleurTableComponent,
    NumerotationComponent,
    NumerotationTableComponent,
    NumerotationCrudComponent,
    AgrementEquipementComponent,
    AgrementEquipementTableComponent,
    AgrementEquipementCrudComponent,
    AvisEtuteTechniqueDialogComponent,
    HistoriqueTraitementComponent,
    AvisTechniqueInfosComponent,
    EncaissementDirectComponent,
    EncaissementDirectCrudComponent,
    GenerationRedevanceComponent,
    GenerationRedevanceCrudComponent,
    RetraitAutorisationDialogComponent,
    FrequencesComponent,
    FrequencesTableComponent,
    FrequencesCrudComponent,
    ClientDirectionTechniqueComponent,
    ClientDetailsComponent,
    ClientDetailsReleveCompteComponent,
    ClientDetailsEncaissementsComponent,
    ClientDetailsFacturesComponent,
    ClientDetailsFichesTechniques,
    ClientDetailsDevisComponent,
    ClientCrudDomaineComponent,
    ClientCrudServiceConfianceComponent,
    ClientCrudPrestationsDiversesComponent,
    ClientCrudServiceAValeurAjouteComponent,
    ClientCrudAutorisationGeneraleComponent,
    ClientCrudAgrementInstalleurComponent,
    ClientCrudAgrementEquipementComponent,
    ClientCrudNumerotationComponent,
    FrequencesCrudComponent,
    StationFrequencesDialogComponent,
    CanalFrequencesDialogComponent,
    ClientDetailsImapyesComponent,
    ImportDocumentsComponent,
    ImportComptesComponent,
    TraitementBilanComponent,
    RecapRedevancesComponent,
    AutorisationsPostalesComponent,
    AutorisationsPostalesTableComponent,
    AutorisationsPostalesCrudComponent,
    ImportDocumentDialogComponent,
    ClientDfcComponent,
    ClientDfcDetailsComponent,
    ClientDfcDetailsReleveCompteComponent,
    ClientDfcDetailsImapyesComponent,
    ClientDfcDetailsFacturesComponent,
    ClientDfcDetailsEncaissementsComponent,
    ClientDfcDetailsDevisComponent,
    ClientDfcEncaissementCrudComponent,
    FichesTechniquesDapTableComponent,
    CaPostalDeterminationShellComponent,
    FicheTechniquesActivitesPostalesComponent,
    ImportBilanDialogComponent,
    ClientDfcPenalitesCrudComponent,
    FichesTechniquesDapCrudComponent,
  ],
  imports: [
    CommonModule,
    FactureRoutingModule,
    SharedModule,
    ReactiveFormsModule,
    FormsModule,
    PdfViewerModule,
    ScrollingModule,
    MaterialModule,
  ] ,

})
export class FactureModule { }
